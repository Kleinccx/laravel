<?php

namespace App\Http\Controllers;


use Illuminate\Http\Request;

use Illuminate\Support\Facades\Route;

class PagesController extends Controller
{
    public function about()
    {
        return view('about');
    }
}
