
@include('templates.header')


    <x-navbar/>



    <h2>Product Details</h2>
   <img src = "{{$product->imageUrl}}"/>
   <h1> Product Name: {{$product->name }}</h1>
   <h1> Product Quantity: {{$product->quantity }}</h1>
   <h1> Product Price: {{$product->price] }}</h1>
   <h1> Product Description: {{$product->description }}</h1>


    <h2> Featured Products </h2>

    <x-products :products=$products/>

   

