<table border = "1">
        <tr>

        <th> Name </th>
        <th> Quantity </th>
        <th> Price </th>
        <th> Description </th>
        <th> Image </th>
</tr>
<tr>
@foreach($products as $product)
<td><a href = "/products/{{products->id}}">  
        {{$product->name }}</a> </td>
        <td> {{$product->quantity }} </td>
        <td> {{$product->price }}</td>
        <td> {{$product->description }} </td>
        <td> <img src = "{{$product->imageUrl }}" width = "50"/></td>

</tr>
    @endforeach
</table>