
@include('templates.header')


    <x-navbar/>



    <h2>All Products </h2>
    <x-products :products=$products/>

    @include('templates.footer')
   

