<table border = "1">
        <tr>

        <th> Name </th>
        <th> Quantity </th>
        <th> Price </th>
        <th> Description </th>
        <th> Image </th>
</tr>
<tr>
<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<td><a href = "/products/<?php echo e(products->id); ?>">  
        <?php echo e($product->name); ?></a> </td>
        <td> <?php echo e($product->quantity); ?> </td>
        <td> <?php echo e($product->price); ?></td>
        <td> <?php echo e($product->description); ?> </td>
        <td> <img src = "<?php echo e($product->imageUrl); ?>" width = "50"/></td>

</tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table><?php /**PATH D:\SaludagaLaravel\resources\views/components/products.blade.php ENDPATH**/ ?>