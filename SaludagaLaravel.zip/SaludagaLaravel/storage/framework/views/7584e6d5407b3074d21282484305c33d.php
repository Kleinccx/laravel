<a href = "/"> All Products </a> |
<a href = "/"> Login </a> |
<a href = "/"> Register </a> |
<a href = "/"> Contact </a> <?php /**PATH D:\SaludagaLaravel\resources\views/components/navbar.blade.php ENDPATH**/ ?>