</body>
</html><?php /**PATH D:\SaludagaLaravel\resources\views/templates/footer.blade.php ENDPATH**/ ?>